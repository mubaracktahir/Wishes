package com.mubaracktahir.wishes.ui.main;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.mubaracktahir.wishes.MainActivity;
import com.mubaracktahir.wishes.R;

import java.util.ArrayList;
import java.util.List;

/**
 * A placeholder fragment containing a simple view.
 */
public class FriendFregment extends Fragment {
    private ListView listView;
    private RecyclerView recyclerView;
    View root;
    private List<Friends> friendsList;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        friendsList = new ArrayList<>();
        friendsList.add(new Friends("Mubarack Tahir","14 june, 2019",100));
        friendsList.add(new Friends("Rahimat Idris","07 November, 2020",100));
        friendsList.add(new Friends("Faridat Muhammad ","15 june, 2039",100));
        friendsList.add(new Friends("Faridat Muhammad ","15 december, 2039",100));
        friendsList.add(new Friends("Mubarack Tahir","14 june, 2019",100));
        friendsList.add(new Friends("Rahimat Idris","07 November, 2020",100));
        friendsList.add(new Friends("Faridat Muhammad ","15 may, 2039",100));
        friendsList.add(new Friends("james Bond ","15 july, 2039",100));
        friendsList.add(new Friends("Mubarack Tahir","14 september, 2019",100));
        friendsList.add(new Friends("Temi baba jide","07 November, 2020",100));
        friendsList.add(new Friends("Muhammad Awwal ","15 june, 1993",100));
        friendsList.add(new Friends("Faridat Muhammad ","15 april, 1950",100)); friendsList.add(new Friends("Mubarack Tahir","14 june, 2019",100));
        friendsList.add(new Friends("Kudirat Idris","07 june, 2020",100));
        friendsList.add(new Friends("Farid Tahir ","15 january, 2001",100));
        friendsList.add(new Friends("Safiya Muhammad ","15 august, 2002",100)); friendsList.add(new Friends("Mubarack Tahir","14 june, 2019",100));
        friendsList.add(new Friends("Rahimat Idris","07 November, 2001",100));
        friendsList.add(new Friends("Abdulsalam Muhammad ","15 june, 2012",100));
        friendsList.add(new Friends("Hauwa Muhammad ","15 june, 2013",100));



       // sendNewFriend();
    }
    public static Friends fred;
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.friend_fragment_main, container, false);
        recyclerView =  root.findViewById(R.id.recyclerview);
        RecyclerViewAdapter recyclerViewAdapter = new RecyclerViewAdapter(getContext(),friendsList);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(recyclerViewAdapter);
        //recyclerView.setOnClickListener(new );
        setHasOptionsMenu(true);
        return root;
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        //inflater.inflate(R.menu.friends_menu,menu);

    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        return super.onOptionsItemSelected(item);
    }
}