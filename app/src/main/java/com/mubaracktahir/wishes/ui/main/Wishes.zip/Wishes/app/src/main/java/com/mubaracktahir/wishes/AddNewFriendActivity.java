package com.mubaracktahir.wishes;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.os.Build;
import android.os.Bundle;

import com.mubaracktahir.wishes.ui.main.FriendFregment;
import com.mubaracktahir.wishes.ui.main.Friends;

public class AddNewFriendActivity extends AppCompatActivity {
    private Friends friend;
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_friend);
        getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(),R.color.white));
        //friend = new Friends();
    }


}
