package com.mubaracktahir.wishes;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;
import com.mubaracktahir.wishes.ui.main.FriendFregment;
import com.mubaracktahir.wishes.ui.main.Friends;
import com.mubaracktahir.wishes.ui.main.MyAdapter;
import com.mubaracktahir.wishes.ui.main.NotificationFregment;
import com.mubaracktahir.wishes.ui.main.QouteFregment;
import com.mubaracktahir.wishes.ui.main.SectionsPagerAdapter;

public class MainActivity extends AppCompatActivity {
    private ViewPager viewPager;
    public static Context context;
     TabLayout tabs;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context=this;

        //this dude down here makes this particular activity remain portrait

        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);


        //the viewpager changes from one fragment to another using the swipe gesture

        viewPager = findViewById(R.id.view_pager);

        TabLayout tabs = findViewById(R.id.tabs);

        //allowing the tabs to be able to change from one fragment to another using the tabs

        tabs.setupWithViewPager(viewPager);


        //calling the setupViewPager method

        setUpViewPager(viewPager);
        tabs.getTabAt(0).setIcon(R.drawable.friends);
        tabs.getTabAt(1).setIcon(R.drawable.quotes);
        tabs.getTabAt(2).setIcon(R.drawable.notification);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setElevation(0);

        FloatingActionButton fab = findViewById(R.id.fab);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,AddNewFriendActivity.class);
                startActivity(intent);
                //TODO: i will have to do this later
            }
        });

    }
    public void setUpViewPager(ViewPager viewPager){
        SectionsPagerAdapter sectionsPagerAdapter = new SectionsPagerAdapter(this, getSupportFragmentManager());
        sectionsPagerAdapter.addFragment(new FriendFregment(),"");
        sectionsPagerAdapter.addFragment(new QouteFregment(), "");
        sectionsPagerAdapter.addFragment(new NotificationFregment(), "");

        viewPager.setAdapter(sectionsPagerAdapter);
    }
    public void setView(int id){
        viewPager.setCurrentItem(id);
    }
    public void sendNewFriend(Friends friend){


    }
}
