package com.mubaracktahir.wishes.ui.main;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.mubaracktahir.wishes.R;

import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder>{
    private Context mContext;
    private List<Friends> friends;

    public RecyclerViewAdapter(Context context,List<Friends> friends){
        this.mContext = context;
        this.friends = friends;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.friendlist,parent,false);
        MyViewHolder myViewHolder = new MyViewHolder(v);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.name.setText(friends.get(position).getName());
        holder.dob.setText(friends.get(position).getDob());
        //holder.daysRemaining.setText(friends.get(position).getDaysRemaining());
       // holder.image.setImageResource(friends.get(position).getImage());

    }

    @Override
    public int getItemCount() {
        return friends.size();
    }

    public static  class MyViewHolder extends RecyclerView.ViewHolder{

        TextView name;
        private TextView dob;
        private TextView daysRemaining;
        private TextView day;
        private ImageView image;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.profilePicture);
            name = itemView.findViewById(R.id.name);
            dob = itemView.findViewById(R.id.date_of_birth);
            daysRemaining = itemView.findViewById(R.id.days);
            day = itemView.findViewById(R.id.d);
        }
    }

}
